Bloco do carrossel é de mesmo tamanho nas 3 pag

* Body pag1
height: 696px;
width: 612px;
left: 0px;
top: 0px;
border-radius: 0px;
>css
position: absolute;
left: 0%;
right: 0%;
top: 0%;
bottom: 0%;

background: #333740;


* Fundo do carrossel

* Menu
height: 18px;
width: 194px;
left: 33px;
top: 27px;
border-radius: 0px;
>css
position: absolute;
left: 5.39%;
right: 62.91%;
top: 3.88%;
bottom: 93.53%;

* Imagem 1 do carrossel
height: 348px;
width: 531.6950073242188px;
left: 80px;
top: 0px;
border-radius: 0px;
>css
position: absolute;
left: 13.07%;
right: 0.05%;
top: 0%;
bottom: 50%;

background: SRC\imgBoxBig-2.svg;


* Box1 pag1
height: 237px;
width: 306px;
left: 0px;
top: 348px;
border-radius: 0px;
background: #FFFFFF;
>css
position: absolute;
left: 0%;
right: 50%;
top: 50%;
bottom: 15.95%;

background: #FFFFFF;

* Titulo box1 pag1
height: 48px;
width: 91px;
left: 33px;
top: 384px;
border-radius: nullpx;
>css
position: absolute;
width: 91px;
height: 48px;
left: 33px;
top: 384px;

font-family: Hind;
font-style: normal;
font-weight: bold;
font-size: 30px;
line-height: 48px;
/* identical to box height */

display: flex;
align-items: flex-end;

color: #000000;

* Paragrafo box1 pag1

>css
position: absolute;
left: 5.39%;
right: 55.39%;
top: 61.06%;
bottom: 21.7%;

font-family: Hind;
font-style: normal;
font-weight: normal;
font-size: 12px;
line-height: 19px;
display: flex;
align-items: flex-end;
text-align: justify;

color: #000000;

* Box2 pag1
height: 237px;
width: 306px;
left: 306px;
top: 348px;
border-radius: 0px;
>css
position: absolute;
left: 50%;
right: 0%;
top: 50%;
bottom: 15.95%;

background: SRC\imgIndex.svg;

* Footer
height: 111px;
width: 612px;
left: 0px;
top: 0px;
border-radius: 0px;
background: #FFFFFF;
>css
position: absolute;
left: 0%;
right: 0%;
top: 0%;
bottom: 0%;

background: #FFFFFF;


